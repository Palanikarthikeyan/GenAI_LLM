import streamlit as st

st.title("Welcome to Streamlit")

st.image("C:\\Users\\theeba\\Pictures\\tiger.jfif",caption="PlayTime")
st.audio("file.mp3")
st.video("file.mp4")

